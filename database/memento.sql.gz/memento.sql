-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : lun. 27 nov. 2023 à 15:02
-- Version du serveur : 5.7.39
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `memento`
--

-- --------------------------------------------------------

--
-- Structure de la table `post_it`
--

CREATE TABLE `post_it` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(20) NOT NULL,
  `content` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `post_it`
--

INSERT INTO `post_it` (`id`, `user_id`, `title`, `content`, `color`, `date`, `created_at`) VALUES
(3, 1, 'Elit in sunt Nam ex', 'Laboris voluptas rep', '#49aee3', '1990-12-05', '2023-11-22 19:39:34'),
(4, 1, 'Quod dicta sit et ex', 'Maxime architecto pa', '#ffa52b', '1992-08-19', '2023-11-22 19:39:41');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'haruki', 'raclot.raphael@gmail.com', '$2y$10$URwqkDt2Xx0OId1bHURVCO1SnQMCcBSP3MJsTZBVIf8r1maYAw.b6', '2023-11-20 15:02:35'),
(2, 'BenoitPrmt', 'b@b.fr', '$2y$10$EHkb/tNcC3X93qFo6swxjOMk85DXwyZbLu88nXagKPxMPoGEEoPxy', '2023-11-21 13:29:16'),
(3, 'kilian', 'kilian.olry@gmail.com', '$2y$10$YmUrViaen7SETdwWk1ls7ea06DE8ec/y5FH37W69K8A90I7X0jU06', '2023-11-21 13:56:56'),
(4, 'guitendoir', 'test@test.com', '$2y$10$l.hneRsKiiiP7x/a8gQZI.bXKk1aCuA08L7/DMBkZYU4Nv1/OZLiG', '2023-11-21 15:38:45'),
(5, 'Jérôme', 'jemacaraf@gmail.com', '$2y$10$tgHwLTO9WI8jwDbQnZqYMuKl3n7cmVp18//OjWraxtousTNO3gbKG', '2023-11-22 19:35:21');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `post_it`
--
ALTER TABLE `post_it`
  ADD PRIMARY KEY (`id`),
  ADD KEY `memento_users_id_foreign` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `post_it`
--
ALTER TABLE `post_it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
